# Contador de bebidas

1. Crea un repositorio público en GitHub.
2. Sube `index.html` y `manifest.json`.
3. En Settings > Pages, selecciona Deploy from a branch, rama `main`, carpeta `/root`.
4. Guarda y abre la URL que GitHub te dé.
5. En iPhone: Safari > Compartir > Añadir a pantalla de inicio.

La aplicación guarda los contadores e historial en el almacenamiento local del navegador del dispositivo.
